# Loan-Delinquency-Prediction-Analatyics-Vidhya-24-Aug-2019
Loan Delinquency Prediction for Next Month EMI using XGBoost Algorithm
